# 🧮 Grade Calculator - Task 2

This is a complete, self-contained Flutter project structure for Task 2. It implements a modern Grade Calculator that computes grade averages, checks passing thresholds, and includes responsive design.

---

## 🚀 Where to Test This App & How

### Option 1: Instant Browser Test (No Setup Required)
The fastest way to test this application without installing anything:
1. Open your web browser and go to **[DartPad for Flutter](https://dartpad.dev/flutter)**.
2. Delete all default code in the left editor panel.
3. Open the file **[lib/main.dart](file:///C:/Users/toxic/Downloads/Day1/task2_grade_calculator/lib/main.dart)** in your browser/editor.
4. Copy the entire content of `lib/main.dart` and paste it into the DartPad editor.
5. Click the **Run** button at the top.
6. The app will launch immediately in the live preview panel on the right! You can enter grades, click "Llogarit" (Calculate), and test validation.

---

### Option 2: Using FlutLab.io (Online IDE)
If you want to compile and build the actual APK or Web project online:
1. Go to **[FlutLab.io](https://flutlab.io)** and log in (free account).
2. Click **Create Project** and choose a **Flutter template** (e.g. Flutter Web or Mobile).
3. Upload the files from this folder (`pubspec.yaml`, `lib/main.dart`, and `web/index.html`) to replace the default ones, or copy/paste the content of `lib/main.dart` into FlutLab's `main.dart` editor.
4. Click the **Build** or **Run** button (usually a play icon) in the header.
5. FlutLab will run a VM and show you a preview of the screen.

---

### Option 3: Using Replit
If you prefer Replit:
1. Go to **[Replit.com](https://replit.com)**.
2. Search for the **Flutter** template and create a new repl.
3. Replace the `lib/main.dart` inside Replit with the code from your **[lib/main.dart](file:///C:/Users/toxic/Downloads/Day1/task2_grade_calculator/lib/main.dart)** file.
4. Click **Run** at the top. Replit will boot up a VM, fetch the packages, and run the app in an embedded web preview.

---

### Option 4: Local testing using Flutter SDK (PC/Laptop)
If you have the Flutter SDK installed on your system:
1. Open your terminal (PowerShell, Command Prompt, or Git Bash).
2. Navigate to this project folder:
   ```bash
   cd "C:\Users\toxic\Downloads\Day1\task2_grade_calculator"
   ```
3. Get the packages specified in the pubspec:
   ```bash
   flutter pub get
   ```
4. Run the project on Chrome (or a connected emulator/device):
   ```bash
   flutter run -d chrome
   ```
   *(If you want to run it on a mobile emulator, just type `flutter run` and select your device).*
