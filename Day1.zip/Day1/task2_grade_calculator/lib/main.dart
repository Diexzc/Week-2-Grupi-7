import 'package:flutter/material.dart';

void main() => runApp(const GradeCalculatorApp());

class GradeCalculatorApp extends StatelessWidget {
  const GradeCalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Grade Calculator',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0F172A), // Tailwind Slate-900
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF10B981), // Emerald-500
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const CalculatorPage(),
    );
  }
}

class CalculatorPage extends StatefulWidget {
  const CalculatorPage({super.key});

  @override
  State<CalculatorPage> createState() => _CalculatorPageState();
}

class _CalculatorPageState extends State<CalculatorPage> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _mathController = TextEditingController();
  final TextEditingController _scienceController = TextEditingController();
  final TextEditingController _englishController = TextEditingController();

  double? _average;
  String _status = '';
  Color _statusColor = Colors.grey;
  String _feedbackMessage = '';

  @override
  void dispose() {
    _mathController.dispose();
    _scienceController.dispose();
    _englishController.dispose();
    super.dispose();
  }

  void _calculateGrade() {
    if (_formKey.currentState!.validate()) {
      double math = double.parse(_mathController.text);
      double science = double.parse(_scienceController.text);
      double english = double.parse(_englishController.text);

      double avg = (math + science + english) / 3;

      bool isHundredScale = (math > 10 || science > 10 || english > 10);
      double passThreshold = isHundredScale ? 50.0 : 5.0;

      setState(() {
        _average = avg;
        if (avg >= passThreshold) {
          _status = 'Kalon (Pass)';
          _statusColor = const Color(0xFF10B981);
          _feedbackMessage = isHundredScale 
              ? 'Të lumtë! Ke arritur një rezultat të shkëlqyer.' 
              : 'Urime! Ke kaluar me sukses.';
        } else {
          _status = 'Duhet përmirësim (Needs Improvement)';
          _statusColor = const Color(0xFFEF4444);
          _feedbackMessage = 'Mos u dorëzo! Vazhdo të mësosh dhe do t\'ia dalësh herën tjetër.';
        }
      });
    }
  }

  void _clearAll() {
    _formKey.currentState!.reset();
    _mathController.clear();
    _scienceController.clear();
    _englishController.clear();
    setState(() {
      _average = null;
      _status = '';
      _statusColor = Colors.grey;
      _feedbackMessage = '';
    });
  }

  String? _validateGrade(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Kjo fushë nuk mund të jetë bosh';
    }
    final numValue = double.tryParse(value);
    if (numValue == null) {
      return 'Ju lutem vendosni një numër të vlefshëm';
    }
    if (numValue < 0) {
      return 'Nota nuk mund të jetë negative';
    }
    if (numValue > 100) {
      return 'Nota nuk mund të jetë më e madhe se 100';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isDesktop = screenWidth > 700;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFF0F172A),
              Color(0xFF064E3B),
              Color(0xFF0F172A),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  maxWidth: isDesktop ? 650 : 450,
                ),
                child: Form(
                  key: _formKey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Icon(
                        Icons.calculate_outlined,
                        size: 64,
                        color: Color(0xFF34D399),
                      ),
                      const SizedBox(height: 12.0),
                      const Text(
                        'Llogaritësi i Notave',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 28.0,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.5,
                        ),
                      ),
                      const SizedBox(height: 6.0),
                      Text(
                        'Vendosni notat tuaja për të llogaritur mesataren dhe statusin',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 14.0,
                          color: Colors.white.withValues(alpha: 0.6),
                        ),
                      ),
                      const SizedBox(height: 28.0),
                      Container(
                        padding: const EdgeInsets.all(28.0),
                        decoration: BoxDecoration(
                          color: const Color(0xFF1E293B).withValues(alpha: 0.7),
                          borderRadius: BorderRadius.circular(24.0),
                          border: Border.all(
                            color: Colors.white.withValues(alpha: 0.1),
                            width: 1.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.3),
                              blurRadius: 15,
                              offset: const Offset(0, 8),
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            if (isDesktop)
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: _buildGradeField(
                                      controller: _mathController,
                                      label: 'Matematikë',
                                      icon: Icons.functions,
                                    ),
                                  ),
                                  const SizedBox(width: 16.0),
                                  Expanded(
                                    child: _buildGradeField(
                                      controller: _scienceController,
                                      label: 'Shkencë',
                                      icon: Icons.science_outlined,
                                    ),
                                  ),
                                  const SizedBox(width: 16.0),
                                  Expanded(
                                    child: _buildGradeField(
                                      controller: _englishController,
                                      label: 'Anglisht',
                                      icon: Icons.translate,
                                    ),
                                  ),
                                ],
                              )
                            else
                              Column(
                                children: [
                                  _buildGradeField(
                                    controller: _mathController,
                                    label: 'Matematikë',
                                    icon: Icons.functions,
                                  ),
                                  const SizedBox(height: 16.0),
                                  _buildGradeField(
                                    controller: _scienceController,
                                    label: 'Shkencë',
                                    icon: Icons.science_outlined,
                                  ),
                                  const SizedBox(height: 16.0),
                                  _buildGradeField(
                                    controller: _englishController,
                                    label: 'Anglisht',
                                    icon: Icons.translate,
                                  ),
                                ],
                              ),
                            const SizedBox(height: 24.0),
                            Row(
                              children: [
                                Expanded(
                                  flex: 2,
                                  child: SizedBox(
                                    height: 50.0,
                                    child: ElevatedButton(
                                      onPressed: _calculateGrade,
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: const Color(0xFF10B981),
                                        foregroundColor: Colors.white,
                                        elevation: 2,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(12.0),
                                        ),
                                      ),
                                      child: const Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Icon(Icons.done_all_rounded, size: 20),
                                          SizedBox(width: 8),
                                          Text(
                                            'Llogarit',
                                            style: TextStyle(
                                              fontSize: 16.0,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12.0),
                                Expanded(
                                  flex: 1,
                                  child: SizedBox(
                                    height: 50.0,
                                    child: OutlinedButton(
                                      onPressed: _clearAll,
                                      style: OutlinedButton.styleFrom(
                                        foregroundColor: Colors.white.withValues(alpha: 0.8),
                                        side: BorderSide(
                                          color: Colors.white.withValues(alpha: 0.2),
                                          width: 1.5,
                                        ),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(12.0),
                                        ),
                                      ),
                                      child: const Text(
                                        'Fshi',
                                        style: TextStyle(
                                          fontSize: 15.0,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            if (_average != null) ...[
                              const SizedBox(height: 28.0),
                              Divider(
                                color: Colors.white.withValues(alpha: 0.1),
                                thickness: 1,
                              ),
                              const SizedBox(height: 20.0),
                              Center(
                                child: Column(
                                  children: [
                                    const Text(
                                      'Nota Mesatare',
                                      style: TextStyle(
                                        fontSize: 14.0,
                                        letterSpacing: 1.0,
                                        color: Colors.grey,
                                      ),
                                    ),
                                    const SizedBox(height: 4.0),
                                    Text(
                                      _average!.toStringAsFixed(2),
                                      style: const TextStyle(
                                        fontSize: 48.0,
                                        fontWeight: FontWeight.w900,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 16.0),
                              Center(
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 20.0,
                                    vertical: 8.0,
                                  ),
                                  decoration: BoxDecoration(
                                    color: _statusColor.withValues(alpha: 0.15),
                                    borderRadius: BorderRadius.circular(30.0),
                                    border: Border.all(
                                      color: _statusColor,
                                      width: 1.5,
                                    ),
                                  ),
                                  child: Text(
                                    _status,
                                    style: TextStyle(
                                      color: _statusColor,
                                      fontSize: 14.0,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 16.0),
                              Text(
                                _feedbackMessage,
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  fontSize: 14.0,
                                  fontStyle: FontStyle.italic,
                                  color: Colors.white70,
                                ),
                              ),
                            ]
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildGradeField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      validator: _validateGrade,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: const Color(0xFF34D399)),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.0),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.0),
          borderSide: BorderSide(
            color: Colors.white.withValues(alpha: 0.2),
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.0),
          borderSide: const BorderSide(
            color: Color(0xFF10B981),
            width: 2.0,
          ),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.0),
          borderSide: const BorderSide(
            color: Color(0xFFEF4444),
            width: 1.5,
          ),
        ),
        filled: true,
        fillColor: Colors.white.withValues(alpha: 0.03),
      ),
    );
  }
}
