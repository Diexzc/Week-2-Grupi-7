# Internal Internship - Day 1: Dart Refresher & Flutter Setup

This directory contains the tasks and documentation completed for **Day 1** of the Internal Internship.

## 📁 Files Included
- **[c_to_dart_refresher.dart](file:///C:/Users/toxic/Downloads/Day1/c_to_dart_refresher.dart)**: An executable Dart file showing side-by-side comparisons of variables, types, loops, conditions, and functions in C vs. Dart.
- **[main.dart (Task 1)](file:///C:/Users/toxic/Downloads/Day1/main.dart)**: A fully functional, responsive, and visually polished Profile Card App in Flutter.
- **[task2.dart (Task 2)](file:///C:/Users/toxic/Downloads/Day1/task2.dart)**: A fully functional Grade Calculator UI in Flutter with validation, average calculation, status display, and dynamic feedback.

---

## 📘 Day 1 Learning & Concepts

### 1. C ➡️ Dart Comparison Cheat Sheet
- **Variables & Types**: 
  - Dart uses `int` and `double` (all numbers inherit from a `num` class), unlike C which has `int`, `float`, `double`, `short`, `long`.
  - Dart has a built-in `String` type representing UTF-16 strings, whereas C uses character arrays (`char[]` or `char*`).
  - Dart is statically typed but supports type inference using `var`.
  - Booleans are natively supported with the `bool` type (and must be strictly `true` or `false`).
- **If/Else Conditions**:
  - In C, any non-zero value acts as `true` (e.g., `if (1)` or `if (ptr)`).
  - In Dart, type checking is strict: `if` conditions **must** evaluate to a boolean (`bool`). `if (1)` will throw a compile error.
- **Loops**:
  - Standard `for`, `while`, and `do-while` loops work identically to C.
  - Dart adds collection loops like `for (var item in list)` and standard functional programming methods like `list.forEach((item) => ... )`.
- **Functions**:
  - Dart functions support return types and parameter lists similar to C.
  - Dart adds **arrow syntax** (`=>`) for single-expression functions.
  - Dart supports **named parameters** enclosed in `{}` and **positional optional parameters** in `[]`, which are heavily utilized in Flutter for configuring widget properties.

### 2. What is Flutter and Why is it Used?
**Flutter** is Google's open-source UI software development kit (SDK) used to build cross-platform applications for Android, iOS, Web, Windows, macOS, and Linux from a single codebase.
- **Single Codebase**: Write code once and run it everywhere, reducing development time and maintenance cost.
- **High Performance**: Flutter apps compile directly to native ARM machine code (or Javascript/WebAssembly for Web) using Dart's compiler, bypassing web-view wrappers or bridge interfaces.
- **Skia/Impeller Rendering**: Flutter renders its own pixels directly onto the screen instead of wrapping native platform controls. This ensures UI consistency across different devices and OS versions.

### 3. Basic Flutter Structure
- `main()`: The starting entry point of the application (similar to C's `main` function).
- `runApp(Widget app)`: The root function that inflates the given widget and attaches it to the screen.
- `MaterialApp`: A core widget that wraps the application and sets up the design system (Material Design), routing, localization, and theme.
- `Scaffold`: Implements the basic Material Design visual layout structure. It provides APIs for adding an `AppBar`, `Drawer`, `FloatingActionButton`, `BottomNavigationBar`, and the main screen `body`.

### 4. Basic Widgets Used
- `Text`: Displays a string of text with customizable styles.
- `Icon`: Draws a vector graphic icon from a font library (e.g., `Icons.email`).
- `Image`: Displays an image from assets, networks, or files.
- `Container`: A convenience widget that combines common painting, positioning, and sizing widgets.
- `Row`: A layout widget that displays its children in a horizontal array.
- `Column`: A layout widget that displays its children in a vertical array.
- `ElevatedButton`: A Material Design button that elevates when pressed, handling user click interactions.
- `TextField` / `TextFormField`: Form widgets to take input from the user (used extensively in Task 2).

---

## 🧮 Task 2: Grade Calculator Features
- **Form Validation**: Uses `Form` and `TextFormField` to validate that inputs:
  1. Are not empty.
  2. Are valid numbers (using `double.tryParse`).
  3. Are positive and within a valid range (0 to 100).
- **Flexible Scale**: Dynamically detects if grades are on a 1-10 scale or 0-100 scale.
- **Dynamic Average & Status**: Calculates the average with exactly two decimal places using `.toStringAsFixed(2)` and displays a status badge:
  - **Kalon (Pass)**: If average is $\ge$ 5.0 (for 1-10 scale) or $\ge$ 50.0 (for 0-100 scale). Shown in **Emerald Green**.
  - **Duhet përmirësim (Needs Improvement)**: If the average is below the passing threshold. Shown in **Vibrant Red**.
- **Responsive Layout**: Designed dynamically using `MediaQuery`. Fits perfectly on wide screens (desktop side-by-side) and narrow screens (mobile column layout).

---

## ⚡ Hot Reload, Debugging & Common Build Errors

### Hot Reload vs. Hot Restart
- **Hot Reload**: Injects updated source code files into the running Dart Virtual Machine (VM). It updates the UI in under a second **while preserving the state** of the application.
- **Hot Restart**: Rebuilds the widget tree and restarts the application from the beginning, **destroying the current state** of the app. Use this when you change initialization logic (like `main()`) or global states.

### Basic Debugging Tips
1. **Debug Print**: Use `print('value: $val')` or `debugPrint(...)` to print messages to the console during execution.
2. **Flutter Inspector**: A visual tool to inspect the widget tree, check layout boundaries, and debug spacing issues (padding/margins).
3. **Breakpoints**: Place breakpoints in your IDE (VS Code, Android Studio) to pause execution and inspect variables.

### Common Build/Runtime Errors
- **`A RenderFlex overflowed by X pixels`**: Occurs when layout elements (like `Row` or `Column`) are larger than the physical screen bounds. 
  - *Fix*: Wrap the widgets in an `Expanded`, `Flexible`, or put the entire page in a `SingleChildScrollView`.
- **Null Safety Errors**: Occurs when you try to access a variable that is null, but is expected to be non-nullable.
  - *Fix*: Ensure variable initialization or use safe operators (`?` or `??`).
- **`StatefulWidget` State Modification Outside `setState`**: Modifying variables that impact the UI without calling `setState()`. The variable will change, but the UI will not re-render.
  - *Fix*: Wrap state changes inside `setState(() { ... })`.

---

## 🚀 How to Run the Apps (Task 1 or Task 2)
You can use **FlutLab**, **Replit**, **DartPad**, or your local Flutter SDK setup to run these applications:

### Method 1: Using online tools (DartPad/FlutLab/Replit)
1. Open [DartPad](https://dartpad.dev) or create a new project in [FlutLab](https://flutlab.io) or [Replit](https://replit.com).
2. Ensure you select a **Flutter** template.
3. Replace the entire code inside your `main.dart` with the contents of either [main.dart](file:///C:/Users/toxic/Downloads/Day1/main.dart) (Profile Card) or [task2.dart](file:///C:/Users/toxic/Downloads/Day1/task2.dart) (Grade Calculator).
4. Click **Run** or **Play** to execute the app.

### Method 2: Local Flutter Environment
1. Open terminal and run:
   ```bash
   flutter create day1_tasks
   ```
2. Replace `lib/main.dart` with the code from either file.
3. Connect a physical device/emulator and run:
   ```bash
   flutter run
   ```
