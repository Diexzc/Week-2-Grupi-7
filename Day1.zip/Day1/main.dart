import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Profile Card App',
      debugShowCheckedModeBanner: false,
      // Setting up a premium dark theme
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0F172A), // Tailwind Slate-900
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0D9488), // Teal-600
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const ProfileCardPage(),
    );
  }
}

class ProfileCardPage extends StatefulWidget {
  const ProfileCardPage({super.key});

  @override
  State<ProfileCardPage> createState() => _ProfileCardPageState();
}

class _ProfileCardPageState extends State<ProfileCardPage> {
  // State variables to demonstrate dynamic interactivity (Dart Refresher connection)
  bool _isConnected = false;
  int _connectionCount = 1024;

  void _toggleConnection() {
    setState(() {
      _isConnected = !_isConnected;
      if (_isConnected) {
        _connectionCount++;
      } else {
        _connectionCount--;
      }
    });

    // Showing a modern snackbar message
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          _isConnected 
              ? 'Successfully connected with Nils Shehu!' 
              : 'Connection removed.',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: _isConnected ? const Color(0xFF0D9488) : const Color(0xFFEF4444),
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        // Subtle background gradient for rich aesthetics
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFF0F172A), // Dark Slate
              Color(0xFF1E1E38), // Deep Indigo
              Color(0xFF0F172A),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // 1. Premium Glassmorphic Card Container
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(28.0),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1E293B).withOpacity(0.6), // Slate-800 with opacity
                      borderRadius: BorderRadius.circular(24.0),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.1),
                        width: 1.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.25),
                          blurRadius: 15,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        // 2. Profile Image with an elegant glowing border
                        Container(
                          padding: const EdgeInsets.all(4.0),
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(
                              colors: [
                                Color(0xFF0D9488), // Teal
                                Color(0xFF3B82F6), // Blue
                              ],
                            ),
                          ),
                          child: const CircleAvatar(
                            radius: 60.0,
                            backgroundColor: Color(0xFF1E293B),
                            backgroundImage: NetworkImage(
                              'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
                            ),
                          ),
                        ),
                        const SizedBox(height: 20.0),

                        // 3. Name (Text widget)
                        const Text(
                          'Nils Shehu',
                          style: TextStyle(
                            fontSize: 28.0,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.5,
                          ),
                        ),
                        const SizedBox(height: 6.0),

                        // 4. Role (Text widget with Teal Accent)
                        const Text(
                          'FLUTTER DEVELOPER & UI/UX DESIGNER',
                          style: TextStyle(
                            fontSize: 12.0,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF2DD4BF), // Cyan-400
                            letterSpacing: 1.5,
                          ),
                        ),
                        const SizedBox(height: 20.0),

                        // Divider line
                        Divider(
                          color: Colors.white.withOpacity(0.1),
                          thickness: 1,
                        ),
                        const SizedBox(height: 16.0),

                        // 5. Row of Stats (Row widget with spacing)
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            _buildStatColumn('12', 'Projects'),
                            _buildStatColumn('$_connectionCount', 'Connections'),
                            _buildStatColumn('48', 'Commits'),
                          ],
                        ),
                        const SizedBox(height: 16.0),

                        Divider(
                          color: Colors.white.withOpacity(0.1),
                          thickness: 1,
                        ),
                        const SizedBox(height: 20.0),

                        // 6. Contact Information (Column with rows)
                        Column(
                          children: [
                            _buildContactRow(Icons.email_outlined, 'nils.shehu@bgt.school'),
                            const SizedBox(height: 12.0),
                            _buildContactRow(Icons.phone_android_outlined, '+355 69 123 4567'),
                            const SizedBox(height: 12.0),
                            _buildContactRow(Icons.location_on_outlined, 'Tirana, Albania'),
                          ],
                        ),
                        const SizedBox(height: 28.0),

                        // 7. Interactive ElevatedButton
                        SizedBox(
                          width: double.infinity,
                          height: 50.0,
                          child: ElevatedButton(
                            onPressed: _toggleConnection,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _isConnected 
                                  ? const Color(0xFF334155) // Slate-700 when connected
                                  : const Color(0xFF0D9488), // Teal-600 when not connected
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14.0),
                              ),
                              elevation: _isConnected ? 0 : 4,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  _isConnected ? Icons.check : Icons.person_add_alt_1,
                                  size: 20,
                                ),
                                const SizedBox(width: 8.0),
                                Text(
                                  _isConnected ? 'Connected' : 'Connect with Nils',
                                  style: const TextStyle(
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // Helper method to build a stat entry (Column of Text)
  Widget _buildStatColumn(String value, String label) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        const SizedBox(height: 4.0),
        Text(
          label,
          style: TextStyle(
            fontSize: 12.0,
            color: Colors.white.withOpacity(0.6),
          ),
        ),
      ],
    );
  }

  // Helper method to build a Contact row (Row with Icon and Text)
  Widget _buildContactRow(IconData icon, String text) {
    return Row(
      children: [
        Icon(
          icon,
          size: 20.0,
          color: const Color(0xFF2DD4BF),
        ),
        const SizedBox(width: 14.0),
        Expanded(
          child: Text(
            text,
            style: const TextStyle(
              fontSize: 14.0,
              color: Colors.white90,
            ),
          ),
        ),
      ],
    );
  }
}
