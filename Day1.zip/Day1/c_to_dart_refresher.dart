// Day 1: Dart Refresher for C Programmers
// This file demonstrates the syntax comparison between C and Dart.
// It covers variables, types, conditions, loops, and functions.

void main() {
  print('=== 1. VARIABLES & BASIC TYPES ===');
  demonstrateVariables();

  print('\n=== 2. CONDITIONS (IF/ELSE) ===');
  demonstrateConditions();

  print('\n=== 3. LOOPS ===');
  demonstrateLoops();

  print('\n=== 4. FUNCTIONS ===');
  demonstrateFunctions();
}

// ==========================================
// 1. VARIABLES & BASIC TYPES
// ==========================================
void demonstrateVariables() {
  // --- IN C: ---
  // int age = 20;
  // float height = 1.75;
  // char name[] = "John";
  // bool isStudent = true; // Needs <stdbool.h>

  // --- IN DART: ---
  // Dart is statically typed, but features type inference with 'var'
  int age = 20;               // Integer (64-bit)
  double height = 1.75;       // Double-precision floating point
  String name = 'Nils Shehu'; // Strings are UTF-16 code units (can use ' or ")
  bool isStudent = true;      // Native boolean type

  // Type inference using 'var' (Dart infers the type automatically)
  var dynamicAge = 21; // Dart infers 'int'
  
  // Constants:
  // - 'const': compile-time constant
  // - 'final': run-time constant (can only be set once)
  const double pi = 3.14159;
  final DateTime now = DateTime.now();

  print('Name: $name (Length: ${name.length})'); // String interpolation is built-in ($ variable or ${expression})
  print('Age: $age, Height: ${height}m');
  print('Is Student: $isStudent');
  print('PI: $pi, Current Time: $now');
}

// ==========================================
// 2. CONDITIONS (IF/ELSE)
// ==========================================
void demonstrateConditions() {
  int score = 85;

  // --- IN C: ---
  // if (score >= 90) { ... } else if (score >= 80) { ... } else { ... }

  // --- IN DART: ---
  // Dart if/else syntax is identical to C, but booleans MUST be true/false.
  // In C, non-zero values (like 1, -5, or pointers) are evaluated as true.
  // In Dart, only the boolean value `true` is true. `if (1)` will NOT compile!
  if (score >= 90) {
    print('Grade: A');
  } else if (score >= 80) {
    print('Grade: B');
  } else {
    print('Grade: C or lower');
  }

  // Ternary operator is also supported (same as C)
  String result = score >= 50 ? 'Pass' : 'Fail';
  print('Result: $result');
}

// ==========================================
// 3. LOOPS
// ==========================================
void demonstrateLoops() {
  // --- IN C: ---
  // for (int i = 0; i < 5; i++) { ... }
  // while (condition) { ... }
  // do { ... } while (condition);

  // --- IN DART: ---
  // Basic loops look exactly like C:
  print('Standard for-loop:');
  for (int i = 0; i < 3; i++) {
    print('  Index: $i');
  }

  // Dart lists (arrays) and collections have powerful loop structures:
  var colors = ['Blue', 'Teal', 'Indigo'];
  
  print('For-in loop (similar to foreach in other languages):');
  for (var color in colors) {
    print('  Color: $color');
  }

  print('ForEach method with lambda/arrow function:');
  colors.forEach((color) => print('  Lambda Color: $color'));

  // While loop (same as C)
  int count = 0;
  while (count < 2) {
    print('  While count: $count');
    count++;
  }
}

// ==========================================
// 4. FUNCTIONS
// ==========================================
// --- IN C: ---
// int add(int a, int b) { return a + b; }

// --- IN DART: ---
// Basic functions are declared similarly to C:
int add(int a, int b) {
  return a + b;
}

// Dart supports Arrow Functions (short-hand for single-line return statements):
int multiply(int a, int b) => a * b;

// Dart supports Optional Parameters (using positional [ ] or named { }):
// Named parameters are very common in Flutter. The 'required' keyword ensures
// a parameter must be provided, while others can be optional and have defaults.
void greetUser({required String name, String role = 'Guest'}) {
  print('Hello, $name! Role: $role');
}

void demonstrateFunctions() {
  int sum = add(5, 7);
  int product = multiply(4, 5);

  print('5 + 7 = $sum');
  print('4 * 5 = $product');

  // Calling named parameters (note how we name the arguments):
  greetUser(name: 'Nils', role: 'Flutter Developer');
  greetUser(name: 'Alex'); // Defaults to 'Guest'
}
